<?php

echo $_POST['cursos'];