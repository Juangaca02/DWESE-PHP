<html>

<head>
    <meta charset="UTF8">
</head>

<body>
    <h1>Menu</h1>
    <form action="" method="POST">
        <ul>
            <li><a href="introducir.php">Introducir</a></li>
            <li><a href="mostar.php">Mostrar los datos</a></li>
            <li><a href="buscar.php">Buscar</a></li>
            <li><a href="modificar.php">Modificar</a></li>
            <li><a href="borrar.php">Borrar</a></li>
        </ul>
    </form>
</body>

</html>