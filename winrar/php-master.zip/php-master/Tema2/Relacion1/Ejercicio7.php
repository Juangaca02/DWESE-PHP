<html>
    <head>
        <title>title</title>
    </head>
    <body>
        <?php
        $suma = 0;
        for ($i = 0; $i <= 100; $i++){
            $suma += pow($i, 2);
        }
        echo $suma
        ?>
    </body>
</html>

