<html>
    <head>
        <title>title</title>
    </head>
    <body>
        <a href="calcula.php?operacion=sumaFilas">Suma numero de filas</a><br>
        <a href="calcula.php?operacion=sumaColumnas">Suma numero de columnas</a><br>
        <a href="calcula.php?operacion=sumaFilasYColumnas">Suma numero de filas y columnas</a><br>
        <a href="calcula.php?operacion=sumaDiagonal">Suma diagonal principal</a><br>
        <a href="calcula.php?operacion=matrizTraspuesta">Matriz traspuesta</a>
    </body>
</html>