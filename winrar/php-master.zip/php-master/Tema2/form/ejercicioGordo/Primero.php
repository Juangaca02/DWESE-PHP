<html>
    <head>
        <title>title</title>
    </head>
    <body>
        <form action="Matricula.php" method="POST">
            Nombre: <input type="text" name="nombre"><br>
            Apellidos: <input type="text" name="apell"><br>
            <input type="submit" name="enviar" value="Enviar">
        </form>
    </body>
</html>
