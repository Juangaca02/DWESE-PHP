<?php

echo "<br>Nombre: ".$_POST["nombre"];
echo "<br>Apellidos: ".$_POST["apell"];

echo "<br>Nombre: ".$_GET["nombre"];
echo "<br>Apellidos: ".$_GET["apell"];

echo "<br>Nombre: ".$_REQUEST["nombre"];
echo "<br>Apellidos: ".$_REQUEST["apell"];
