<html>
    <head>
        <title>6</title>
    </head>
    <body>
        <?php
        $paises = ["Madrid", "barcelona", "Londres", "New York", "Los Ángeles", "Chicago"];
        
        foreach ($paises as $key => $value) {
            echo "La ciuada con indice $key tiene el nombre de $value<br>";
        }
        
        ?>
    </body>
</html>
