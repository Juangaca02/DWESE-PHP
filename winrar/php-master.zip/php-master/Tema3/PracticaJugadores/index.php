<<<<<<< HEAD
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h1>Menu</h1>
    <ul>
        <a href="introducir.php">
            <li>Introducir</li>
        </a>
        <a href="mostrar.php">
            <li>Mostrar</li>
        </a>
        <a href="buscar.php">
            <li>Buscar</li>
        </a>
        <a href="modificar.php">
            <li>Modificar</li>
        </a>
        <a href="borrar.php">
            <li>Borrar</li>
        </a>
    </ul>
</body>

=======
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h1>Menu</h1>
    <ul>
        <a href="introducir.php">
            <li>Introducir</li>
        </a>
        <a href="mostrar.php">
            <li>Mostrar</li>
        </a>
        <a href="buscar.php">
            <li>Buscar</li>
        </a>
        <a href="modificar.php">
            <li>Modificar</li>
        </a>
        <a href="borrar.php">
            <li>Borrar</li>
        </a>
    </ul>
</body>

>>>>>>> f94b01f6267d3c5706f2f6cd382322f8042ce4c4
</html>