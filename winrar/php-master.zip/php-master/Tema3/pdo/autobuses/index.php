<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h1>Menu</h1>
    <ul>
        <a href="introducirAutobus.php">
            <li>Introducir autobús</li>
        </a>
        <a href="aniadirViaje.php">
            <li>Introducir viaje</li>
        </a>
        <a href="modificarViaje.php">
            <li>Modificar viaje</li>
        </a>
        <a href="reservar.php">
            <li>reservar</li>
        </a>
    </ul>
</body>

</html>