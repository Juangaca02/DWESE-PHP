<?php

require_once "Conexion.php";
require_once "../Model/Vehiculo.php";

class VehiculoController
{
    public static function insert($o)
    {
        try {
            $conn = new Conexion();
            $stmt = $conn->prepare("INSERT INTO vehiculo VALUES (?,?,?,?,?,?)");
            $stmt->execute([$o->matricula, $o->marca, $o->modelo, $o->color, $o->plazas, $o->fecha_ultima_revision]);
            if ($stmt->rowCount() > 0) {
                $conn = null;

                return true;
            }
        } catch (Exception $ex) {
            echo $ex->getTraceAsString();
        }
        return false;
    }

    public static function getVehiculoByMatricula($matricula)
    {
        try {
            $conn = new Conexion();
            $stmt = $conn->prepare("SELECT * FROM vehiculo WHERE matricula = ?");
            if ($stmt->execute([$matricula])) {
                // Retornar un objeto VehiculoModel o cualquier otra lógica que desees
                return $stmt->fetchObject("VehiculoModel");
            }
        } catch (PDOException $ex) {
            echo $ex->getTraceAsString();
        }

        return null;
    }
}

?>