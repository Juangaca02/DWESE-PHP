<?php

require_once "Conexion.php";
require_once "../Model/Citas.php";

class CitasController
{
    public static function insert($o)
    {
        try {
            $conn = new Conexion();
            $stmt = $conn->prepare("INSERT INTO citas VALUES (?,?,?,?,?)");
            $stmt->execute([$o->matricula, $o->id_itv, $o->fecha, $o->hora, $o->ficha]);
            if ($stmt->rowCount() > 0) {
                $conn = null;

                return true;
            }
        } catch (Exception $ex) {
            echo $ex->getTraceAsString();
        }
        return false;
    }

    public static function getCitasByMatricula($matricula)
    {
        try {
            $conn = new Conexion();
            $stmt = $conn->prepare("SELECT * FROM citas WHERE matricula = ?");
            if ($stmt->execute([$matricula])) {
                // Retornar un array de objetos CitasModel o cualquier otra lógica que desees
                return $stmt->fetchAll(PDO::FETCH_CLASS, "CitasModel");
            }
        } catch (PDOException $ex) {
            echo $ex->getTraceAsString();
        }

        return null;
    }
}

?>