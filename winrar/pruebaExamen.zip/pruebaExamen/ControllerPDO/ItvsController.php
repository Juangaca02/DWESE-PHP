<?php

require_once "Conexion.php";
require_once "../Model/Itvs.php";

class ItvsController
{
    public static function insert($o)
    {
        try {
            $conn = new Conexion();
            $stmt = $conn->prepare("INSERT INTO itvs VALUES (?,?,?,?,?)");
            $stmt->execute([$o->id, $o->provincia, $o->localidad, $o->direccion, $o->telefono]);
            if ($stmt->rowCount() > 0) {
                $conn = null;

                return true;
            }
        } catch (Exception $ex) {
            echo $ex->getTraceAsString();
        }
        return false;
    }

    public static function getItvById($id)
    {
        try {
            $conn = new Conexion();
            $stmt = $conn->prepare("SELECT * FROM itvs WHERE id = ?");
            if ($stmt->execute([$id])) {
                // Retornar un objeto ItvsModel o cualquier otra lógica que desees
                return $stmt->fetchObject("ItvsModel");
            }
        } catch (PDOException $ex) {
            echo $ex->getTraceAsString();
        }

        return null;
    }
}

?>