<?php

require_once "Conexion.php";
require_once "../Model/Usuario.php";

class UsuarioController
{
    public static function insert($o)
    {
        try {
            $conn = new Conexion();
            $stmt = $conn->prepare("INSERT INTO usuario VALUES (?,?,?,?,?)");
            $stmt->execute([$o->provincia, $o->nombre, $o->telefono, $o->user, $o->pass]);
            if ($stmt->rowCount() > 0) {
                $conn = null;

                return true;
            }
        } catch (Exception $ex) {
            echo $ex->getTraceAsString();
        }
        return false;
    }

    public static function select($provincia, $user, $pass)
    {
        try {
            $conn = new Conexion();
            $stmt = $conn->prepare("SELECT * FROM usuario WHERE provincia = ? AND user = ?");
            if ($stmt->execute([$provincia, $user])) {
                if ($o = $stmt->fetch())
                    if (password_verify($pass, $o->pass)) {
                        return new UsuarioModel($o->provincia, $o->nombre, $o->telefono, $o->user, $o->pass);
                    }
            }
        } catch (PDOException $ex) {
            echo $ex->getTraceAsString();
        }

        return null;
    }
}

?>