<?php

require_once "Conexion.php";
require_once "../Model/ItvsModel.php";

class ItvsController
{
    public static function insert($o)
    {
        try {
            $conn = Conexion::getConexion();
            $stmt = $conn->prepare("INSERT INTO itvs VALUES (?,?,?,?,?)");
            $stmt->bind_param("isssi", $o->id, $o->provincia, $o->localidad, $o->direccion, $o->telefono);
            $stmt->execute();
            if ($stmt->affected_rows > 0) {
                $stmt->close();
                $conn->close();
                return true;
            }
        } catch (Exception $ex) {
            echo $ex->getTraceAsString();
        }
        return false;
    }

    public static function getItvById($id)
    {
        try {
            $conn = Conexion::getConexion();
            $stmt = $conn->prepare("SELECT * FROM itvs WHERE id = ?");
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                $result = $stmt->get_result();
                $itv = $result->fetch_object("ItvsModel");

                $stmt->close();
                $conn->close();
                return $itv;
            }
        } catch (Exception $ex) {
            echo $ex->getTraceAsString();
        }

        return null;
    }
}

?>