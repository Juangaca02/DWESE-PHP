<?php

require_once "Conexion.php";
require_once "../Model/UsuarioModel.php";

class UsuarioController
{
    public static function insert($o)
    {
        try {
            $conn = Conexion::getConexion();  // Asume que tienes una clase de conexión (Conexion) que devuelve una instancia de mysqli
            $stmt = $conn->prepare("INSERT INTO usuario VALUES (?,?,?,?,?)");
            $stmt->bind_param("ssiss", $o->provincia, $o->nombre, $o->telefono, $o->user, $o->pass);
            $stmt->execute();
            if ($stmt->affected_rows > 0) {
                $stmt->close();
                $conn->close();
                return true;
            }
        } catch (Exception $ex) {
            echo $ex->getTraceAsString();
        }
        return false;
    }

    public static function select($provincia, $user, $pass)
    {
        try {
            $conn = Conexion::getConexion();
            $stmt = $conn->prepare("SELECT * FROM usuario WHERE provincia = ? AND user = ?");
            $stmt->bind_param("ss", $provincia, $user);
            if ($stmt->execute()) {
                $result = $stmt->get_result();
                if ($result->num_rows > 0) {
                    $o = $result->fetch_object("UsuarioModel");
                    if (password_verify($pass, $o->pass)) {
                        $stmt->close();
                        $conn->close();
                        return $o;
                    }
                }
            }
        } catch (Exception $ex) {
            echo $ex->getTraceAsString();
        }

        return null;
    }
}

?>