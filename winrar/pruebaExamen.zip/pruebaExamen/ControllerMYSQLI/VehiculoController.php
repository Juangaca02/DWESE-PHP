<?php

require_once "Conexion.php";
require_once "../Model/VehiculoModel.php";

class VehiculoController
{
    public static function insert($o)
    {
        try {
            $conn = Conexion::getConexion();
            $stmt = $conn->prepare("INSERT INTO vehiculo VALUES (?,?,?,?,?,?)");
            $stmt->bind_param("sssiis", $o->matricula, $o->marca, $o->modelo, $o->color, $o->plazas, $o->fecha_ultima_revision);
            $stmt->execute();
            if ($stmt->affected_rows > 0) {
                $stmt->close();
                $conn->close();
                return true;
            }
        } catch (Exception $ex) {
            echo $ex->getTraceAsString();
        }
        return false;
    }

    public static function getVehiculoByMatricula($matricula)
    {
        try {
            $conn = Conexion::getConexion();
            $stmt = $conn->prepare("SELECT * FROM vehiculo WHERE matricula = ?");
            $stmt->bind_param("s", $matricula);
            if ($stmt->execute()) {
                $result = $stmt->get_result();
                $vehiculo = $result->fetch_object("VehiculoModel");

                $stmt->close();
                $conn->close();
                return $vehiculo;
            }
        } catch (Exception $ex) {
            echo $ex->getTraceAsString();
        }

        return null;
    }
}

?>