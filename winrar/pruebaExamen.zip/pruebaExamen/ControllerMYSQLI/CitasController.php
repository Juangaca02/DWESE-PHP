<?php

require_once "Conexion.php";
require_once "../Model/CitasModel.php";

class CitasController
{
    public static function insert($o)
    {
        try {
            $conn = Conexion::getConexion();  // Asume que tienes una clase de conexión (Conexion) que devuelve una instancia de mysqli
            $stmt = $conn->prepare("INSERT INTO citas VALUES (?,?,?,?,?)");
            $stmt->bind_param("siiss", $o->matricula, $o->id_itv, $o->fecha, $o->hora, $o->ficha);
            $stmt->execute();
            if ($stmt->affected_rows > 0) {
                $stmt->close();
                $conn->close();
                return true;
            }
        } catch (Exception $ex) {
            echo $ex->getTraceAsString();
        }
        return false;
    }

    public static function getCitasByMatricula($matricula)
    {
        try {
            $conn = Conexion::getConexion();
            $stmt = $conn->prepare("SELECT * FROM citas WHERE matricula = ?");
            $stmt->bind_param("s", $matricula);
            if ($stmt->execute()) {
                $result = $stmt->get_result();
                $citas = array();

                while ($o = $result->fetch_object("CitasModel")) {
                    $citas[] = $o;
                }

                $stmt->close();
                $conn->close();
                return $citas;
            }
        } catch (Exception $ex) {
            echo $ex->getTraceAsString();
        }

        return null;
    }
}

?>